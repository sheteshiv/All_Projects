package com.la.pageObjects;

public class LogoutPage {

}
